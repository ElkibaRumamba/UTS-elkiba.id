package main

import (
	"fmt"
	"os/exec"
	"strings"
)

// Book struct untuk mewakili informasi buku
type Book struct {
	Name   string
	Amount int
}

// BorrowHistory struct untuk mewakili riwayat peminjaman buku
type BorrowHistory struct {
	BookName string
	Quantity int
}

// User struct untuk mewakili informasi pengguna
type User struct {
	Username      string
	NPM           string
	Gender        string
	FavoriteFood  string
	FavoriteDrink string
}

// Variabel global untuk data pengguna, daftar buku, dan riwayat peminjaman
var users = []User{
	{"Andi", "10000001", "Laki-laki", "Nasi Goreng", "Teh Manis"},
	{"Budi", "10000002", "Laki-laki", "Bakso", "Es Jeruk"},
}
var books = []Book{
	{"Pemrograman", 10},
	{"Film", 5},
	{"Printing", 20},
}
var borrowHistory []BorrowHistory

// Variabel global untuk pengguna yang sedang login
var loggedInUser *User

// Fungsi utama
func main() {
	if !UserLogin() {
		fmt.Println("Login gagal. Program berhenti.")
		return
	}

	for {
		ClearScreen() // Membersihkan layar sebelum menampilkan menu utama
		fmt.Println("\n==== Selamat Datang di Perpustakaan Virtual! ====")
		fmt.Println("1. Lihat Informasi Pengguna Program")
		fmt.Println("2. Lihat Daftar Buku")
		fmt.Println("3. Tambah Daftar Buku")
		fmt.Println("4. Tambah Peminjaman Buku")
		fmt.Println("5. Histori Peminjaman Buku")
		fmt.Println("6. Keluar dari Program")
		fmt.Print("Input Menu yang anda inginkan: ")

		var choice int
		fmt.Scanln(&choice)

		switch choice {
		case 1:
			ClearScreen()
			LihatInformasiPenggunaProgram()
		case 2:
			ClearScreen()
			LihatDaftarBuku()
		case 3:
			ClearScreen()
			TambahDaftarBuku()
		case 4:
			ClearScreen()
			TambahPeminjamanBuku()
		case 5:
			ClearScreen()
			HistoriPeminjamanBuku()
		case 6:
			fmt.Println("Terima kasih telah menggunakan program ini. Sampai jumpa!")
			return
		default:
			fmt.Println("Pilihan tidak valid. Silakan coba lagi.")
		}
	}
}

// Fungsi untuk login pengguna
func UserLogin() bool {
	var username, npm string

	fmt.Print("Masukkan Username: ")
	fmt.Scanln(&username)
	fmt.Print("Masukkan NPM: ")
	fmt.Scanln(&npm)

	for i := range users {
		if strings.EqualFold(users[i].Username, username) && users[i].NPM == npm {
			loggedInUser = &users[i]
			fmt.Println("Login berhasil. Selamat datang, ", loggedInUser.Username)
			return true
		}
	}

	fmt.Println("Username atau NPM salah.")
	return false
}

// Fungsi untuk menampilkan informasi pengguna yang sedang login
func LihatInformasiPenggunaProgram() {
	if loggedInUser == nil {
		fmt.Println("Informasi pengguna tidak tersedia.")
		return
	}

	fmt.Println("\n==== Informasi Pengguna Program ====")
	fmt.Println("Username: ", loggedInUser.Username)
	fmt.Println("NPM: ", loggedInUser.NPM)
	fmt.Println("Jenis Kelamin: ", loggedInUser.Gender)
	fmt.Println("Favorit Makanan: ", loggedInUser.FavoriteFood)
	fmt.Println("Minuman Favorit: ", loggedInUser.FavoriteDrink)
	fmt.Println("====================================")
	Pause()
}

// Fungsi untuk menampilkan daftar buku yang tersedia
func LihatDaftarBuku() {
	fmt.Println("\n==== Daftar Buku ====")
	for i, book := range books {
		fmt.Printf("%d. Nama Buku: %s\n   Jumlah: %d\n", i+1, book.Name, book.Amount)
	}
	fmt.Println("=====================")
	Pause()
}

// Fungsi untuk menambah buku baru ke daftar buku
func TambahDaftarBuku() {
	var name string
	var amount int

	fmt.Print("\n==== Tambah Daftar Buku ====\nNama Buku: ")
	fmt.Scanln(&name)
	fmt.Print("Jumlah: ")
	fmt.Scanln(&amount)

	// Menambahkan buku baru ke daftar buku
	books = append(books, Book{Name: name, Amount: amount})
	fmt.Println("Buku berhasil ditambahkan.")
	Pause()
}

// Fungsi untuk menambah riwayat peminjaman buku
func TambahPeminjamanBuku() {
	var bookNumber, borrowAmount int

	LihatDaftarBuku()
	fmt.Print("\nMasukkan Nomor Pinjam Buku (1,2,3,...): ")
	fmt.Scanln(&bookNumber)

	if bookNumber < 1 || bookNumber > len(books) {
		fmt.Println("Nomor buku tidak valid.")
		Pause()
		return
	}

	fmt.Print("Masukkan Jumlah Pinjaman: ")
	fmt.Scanln(&borrowAmount)

	// Memeriksa apakah jumlah peminjaman valid
	if borrowAmount < 1 {
		fmt.Println("Jumlah pinjaman harus lebih besar dari 0.")
		Pause()
		return
	}
	if books[bookNumber-1].Amount < borrowAmount {
		fmt.Println("Jumlah buku tidak mencukupi untuk dipinjam.")
		Pause()
		return
	}

	// Mengurangi jumlah buku yang tersedia dan menambah ke riwayat peminjaman
	books[bookNumber-1].Amount -= borrowAmount
	borrowHistory = append(borrowHistory, BorrowHistory{
		BookName: books[bookNumber-1].Name,
		Quantity: borrowAmount,
	})

	fmt.Println("Peminjaman berhasil dilakukan.")
	Pause()
}

// Fungsi untuk melihat riwayat peminjaman buku
func HistoriPeminjamanBuku() {
	fmt.Println("\n==== Histori Peminjaman Buku ====")
	if len(borrowHistory) == 0 {
		fmt.Println("Tidak ada histori peminjaman.")
	} else {
		for i, history := range borrowHistory {
			fmt.Printf("%d. Nama Buku: %s, Jumlah: %d\n", i+1, history.BookName, history.Quantity)
		}
	}
	fmt.Println("===============================")
	Pause()
}

// Fungsi untuk membersihkan layar terminal
func ClearScreen() {
	cmd := exec.Command("clear") // Menggunakan "clear" untuk Linux dan MacOS
	if _, err := cmd.Output(); err != nil {
		cmd = exec.Command("cmd", "/c", "cls") // Menggunakan "cls" untuk Windows
		cmd.Output()
	}
}

// Fungsi untuk menghentikan sementara sebelum melanjutkan
func Pause() {
	fmt.Println("\nTekan 'Enter' untuk melanjutkan...")
	fmt.Scanln()
}
